var navlinks=document.getElementById("nav-link");
function showmenu(){
    navlinks.style.right="0";
}
function hidemenu(){
    navlinks.style.right="-300px";
}